export interface IBatch
{
    Batch : String,
    Fees : number
}